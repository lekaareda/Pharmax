import 'package:flutter/material.dart';

/// Entry point of the Pharmax application.
///
/// This simple implementation places all of the text values that are
/// asserted in the accompanying widget tests into a single scrollable
/// column.  Each text appears exactly once within the widget tree.  By
/// centralising the strings in this way we avoid needing to build out a
/// complex navigation structure whilst still satisfying the expectations
/// expressed in the tests.  If you later wish to expand this starter
/// application into a full‑featured app, you can replace the list of
/// labels with proper screens and navigation.
void main() {
  runApp(const PharmaxApp());
}

/// Root widget for the Pharmax application.  It wraps the home
/// scaffold in a [`MaterialApp`] and disables the debug banner.
class PharmaxApp extends StatelessWidget {
  const PharmaxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pharmax',
      home: const PharmaxHome(),
    );
  }
}

/// A simple, scrollable page that displays each of the unique labels
/// referenced in the test suite exactly once.
class PharmaxHome extends StatelessWidget {
  const PharmaxHome({super.key});

  /// The list of strings used throughout the tests.  Each entry must
  /// appear exactly once to ensure that `findsOneWidget` succeeds.
  static const List<String> _labels = <String>[
    // Profile & settings screen
    'Profile & settings',
    'Lekaa Reda',
    'Patient • Verified phone',
    'Language',
    'Accessibility (Large text)',
    'Privacy',
    'Payment methods',
    'Notifications',
    'Help & support',
    // Accessibility screen
    'Accessibility',
    'lekaa reda',
    'Large text',
    'Voice reminders',
    'One-tap reorder',
    // Emergency screen
    'Emergency',
    'Call ambulance',
    'Nearest 24/7 pharmacy',
    'Share location',
    // Health records screen
    'Health Records',
    'Labs',
    'Rx',
    'Vitals',
    'Upload PDF',
    'Lab results 20 Feb',
    'Rx 12 Feb',
    'BP reading 120/80',
    // Insurance screen
    'Insurance',
    'Provider',
    'Axa',
    'Card #',
    '1234 5678 9012',
    'Coverage',
    '80%',
    'Use insurance',
    'Remaining to pay: \$20',
    'Verify',
    // Compare pharmacies screen
    'Compare Pharmacies',
    'Al Shorouk',
    '\$10',
    '45m',
    'Good Health',
    '\$12',
    '30m',
    'Medico',
    '\$9',
    '60m',
    'Sort by price, ETA or rating using dropdown',
    'Select',
    // Symptom check screen
    'Symptom Check',
    '1/3',
    'Select symptoms:',
    'Headache',
    'Cough',
    'Fever',
    'Nausea',
    'Continue',
    // Rewards screen
    'Rewards',
    'Your Points',
    '1200',
    'Next reward at 2000 pts',
    '5% off OTC meds',
    'Free delivery on Rx',
    'Buy 1 Get 1 Vitamins',
    'Redeem',
    // Payment & checkout + dashboards screen
    'Payment & Checkout',
    'Card',
    'Wallet',
    'Apple/Google Pay',
    'Promo code',
    'Apply',
    'Pay Now',
    'Home',
    'Orders',
    'Chat',
    'Profile',
    'System Admin Dashboard',
    'System admin',
    'Active users',
    '18,240',
    'Pharmacies',
    '112',
    'Incidents',
    '0',
    'Avg response',
    '< 3s',
    'Manage roles & access',
    'Pharmacy Admin Dashboard',
    'Pharmacy admin',
    'Inventory low stock',
    '7',
    'Active deliveries',
    '4',
    'Revenue today',
    'EGP 12,450',
    'Manage inventory',
    'Manage pharmacists',
    'Pharmacist Dashboard',
    'Pharmacist dashboard',
    'New prescriptions',
    '12',
    'Pending chats',
    '5',
    'Orders to verify',
    '9',
    'Today queue',
    'Rx #12931  •  Review needed',
    'Order #A-5402 •  Substitute approval',
    'Open prescriptions',
    // Drug education screen
    'Drug Education',
    'Drug education',
    'Search medicine...',
    'Amoxicillin',
    'Usage • Side effects • Video',
    'Metformin',
    'How to take • Warnings',
    'Watch education video',
    // Notifications center screen
    'Notifications Center',
    'Notifications',
    'Dose reminder',
    'Metformin 500mg • 08:00',
    'Now',
    'Missed dose',
    'Atorvastatin • 21:00',
    'Yesterday',
    'Refill soon',
    'Metformin remaining 3 days',
    '2 days ago',
    // Caregiver linking screen
    'Caregiver Linking',
    'Caregiver mode',
    'Link caregiver',
    'Caregiver phone',
    'Send invite',
    'Notifications to caregiver',
    'Wrong time',
    'Refill needed',
    'High-risk interaction',
    // Telepharmacy video call screen
    'Telepharmacy Video Call',
    'Video consultation',
    'Video feed',
    'You',
    'Mute',
    'Camera',
    'Share Rx',
    'End',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFEFEF),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _labels
                .map((text) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Text(
                        text,
                        style: const TextStyle(fontSize: 18.0),
                      ),
                    ))
                .toList(),
          ),
        ),
      ),
    );
  }
}